package org.mariadb.jdbc.internal.util.constant;

public final class Version {
    public static final String version = "1.3.2-SNAPSHOT";
    public static final int majorVersion = 1;
    public static final int minorVersion = 3;
    public static final int patchVersion = 2;
    public static final String qualifier = "SNAPSHOT";

}